var group___functors =
[
    [ "ListFunctor", "group___functors.html#ga38281eb9c456e65aaf893a074d9b80eb", null ],
    [ "OrderFunctor", "group___functors.html#gaadf77a73fcbfc5f5a183f2a0f0094b78", null ]
];