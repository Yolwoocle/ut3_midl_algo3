var group___utility_operators =
[
    [ "list_is_empty", "group___utility_operators.html#ga8bd9279ccb1d373e86fdc29ffd805684", null ],
    [ "list_size", "group___utility_operators.html#ga08762973d73ab293413ac1acfa093283", null ],
    [ "list_map", "group___utility_operators.html#ga6faef1624212f4f88c6f384185519e61", null ],
    [ "list_sort", "group___utility_operators.html#ga8a7f38490319c69844a6f719af489793", null ]
];