var group___type =
[
    [ "List", "group___type.html#ga7f9b44f298354a268147479e7905b44e", null ],
    [ "ptrList", "group___type.html#gaa9503e58af4b68abc7eab8077a8e4a8a", null ]
];