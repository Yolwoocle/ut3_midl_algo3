var files_dup =
[
    [ "list.h", "list_8h.html", "list_8h" ],
    [ "main.c", "main_8c.html", "main_8c" ]
];