var group___main =
[
    [ "Operators applied to the list.", "group___list_operators.html", "group___list_operators" ],
    [ "Main function for testing.", "group___main_function.html", "group___main_function" ]
];