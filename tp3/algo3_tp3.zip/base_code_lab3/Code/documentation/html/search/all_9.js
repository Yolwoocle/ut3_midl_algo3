var searchData=
[
  ['type_20definition_2e_33',['Type definition.',['../group___type.html',1,'']]]
];
