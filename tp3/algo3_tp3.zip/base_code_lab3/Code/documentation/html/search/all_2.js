var searchData=
[
  ['functions_20prototypes_20that_20could_20be_20used_20with_20some_20operators_20on_20list_2e_2',['Functions prototypes that could be used with some operators on List.',['../group___functors.html',1,'']]]
];
