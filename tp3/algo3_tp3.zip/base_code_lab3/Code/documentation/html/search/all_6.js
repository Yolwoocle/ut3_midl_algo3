var searchData=
[
  ['main_25',['main',['../group___main_function.html#ga3c04138a5bfe5d72780bb7e82a18e627',1,'main(int argc, char **argv):&#160;main.c'],['../group___main.html',1,'(Global Namespace)']]],
  ['main_20function_20for_20testing_2e_26',['Main function for testing.',['../group___main_function.html',1,'']]],
  ['main_2ec_27',['main.c',['../main_8c.html',1,'']]]
];
