var searchData=
[
  ['orderfunctor_58',['OrderFunctor',['../group___functors.html#gaadf77a73fcbfc5f5a183f2a0f0094b78',1,'list.h']]]
];
