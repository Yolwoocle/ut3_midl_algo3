var searchData=
[
  ['operators_20allowing_20to_20access_20some_20properties_20or_20apply_20some_20processing_20on_20the_20whole_20list_2e_28',['Operators allowing to access some properties or apply some processing on the whole list.',['../group___utility_operators.html',1,'']]],
  ['operators_20applied_20to_20the_20list_2e_29',['Operators applied to the list.',['../group___list_operators.html',1,'']]],
  ['orderfunctor_30',['OrderFunctor',['../group___functors.html#gaadf77a73fcbfc5f5a183f2a0f0094b78',1,'list.h']]]
];
