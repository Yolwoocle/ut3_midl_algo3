var searchData=
[
  ['ptrlist_59',['ptrList',['../group___type.html#gaa9503e58af4b68abc7eab8077a8e4a8a',1,'list.h']]]
];
