var searchData=
[
  ['printlist_31',['printList',['../group___list_operators.html#ga7aef1e434c4dfc2ae207c24bb209e4b1',1,'main.c']]],
  ['ptrlist_32',['ptrList',['../group___type.html#gaa9503e58af4b68abc7eab8077a8e4a8a',1,'list.h']]]
];
