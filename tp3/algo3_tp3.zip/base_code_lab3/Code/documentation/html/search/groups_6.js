var searchData=
[
  ['type_20definition_2e_69',['Type definition.',['../group___type.html',1,'']]]
];
