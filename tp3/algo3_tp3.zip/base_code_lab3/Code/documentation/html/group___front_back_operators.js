var group___front_back_operators =
[
    [ "list_push_front", "group___front_back_operators.html#ga19419b366bbbc1853745727eaf185c9f", null ],
    [ "list_front", "group___front_back_operators.html#gab9919e25dd2604389e3029a694b9e7d2", null ],
    [ "list_back", "group___front_back_operators.html#gab1029555e544046e33892ed2c8a77b33", null ],
    [ "list_pop_front", "group___front_back_operators.html#ga4ae20f079a3e7c0e1bbf469e741cdc22", null ],
    [ "list_pop_back", "group___front_back_operators.html#ga4d11d986244b4b4ea20cb4e994de72ec", null ]
];