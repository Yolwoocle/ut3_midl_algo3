var group___constructors =
[
    [ "list_create", "group___constructors.html#ga248e4be8e332f8f9f6d533291e6a765c", null ],
    [ "list_push_back", "group___constructors.html#ga7c5a6268c0974c50fe16c4cc3da2cad1", null ],
    [ "list_delete", "group___constructors.html#ga05450301a8cc077d50d6a22f121ef99e", null ]
];