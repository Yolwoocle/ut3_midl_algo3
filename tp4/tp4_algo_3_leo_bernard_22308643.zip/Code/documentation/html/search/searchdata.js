var indexSectionsWithContent =
{
  0: "bfgimprstux",
  1: "s",
  2: "rs",
  3: "bgmprstu",
  4: "mx",
  5: "irs",
  6: "s",
  7: "bf",
  8: "rst"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Modules"
};

