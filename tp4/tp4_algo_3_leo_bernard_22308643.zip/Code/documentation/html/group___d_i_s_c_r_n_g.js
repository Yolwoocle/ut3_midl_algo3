var group___d_i_s_c_r_n_g =
[
    [ "s_rng_", "structs__rng__.html", [
      [ "xsubi", "structs__rng__.html#a9e6b31d739331bece23d9010cfd3ff7b", null ],
      [ "max_value", "structs__rng__.html#a66a44305412e8f2abea882aea5c5c047", null ]
    ] ],
    [ "RNG", "group___d_i_s_c_r_n_g.html#ga68733ca4f88441bab1b08f9a4a94142c", null ],
    [ "rng_initialize", "group___d_i_s_c_r_n_g.html#gaee1a05e7f65ffc7fd51cf229253fcb0c", null ],
    [ "rng_upper_bound", "group___d_i_s_c_r_n_g.html#ga9dfc4b0b1039d7e46095e46bd10ac4c8", null ],
    [ "rng_get_value", "group___d_i_s_c_r_n_g.html#gaadfcf9762b5203a26eec00ddc104ddfa", null ]
];