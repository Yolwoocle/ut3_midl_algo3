var structs__rng__ =
[
    [ "xsubi", "structs__rng__.html#a9e6b31d739331bece23d9010cfd3ff7b", null ],
    [ "max_value", "structs__rng__.html#a66a44305412e8f2abea882aea5c5c047", null ]
];